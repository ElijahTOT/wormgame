///**
// * Blowtorch.js
// *
// *  License: Apache 2.0
// *  author:  Ciar�n McCann
// *  url: http://www.ciaranmccann.me/
// */
/////<reference path="../system/Physics.ts"/>
/////<reference path="../system/Utilies.ts" />
/////<reference path="../Worm.ts" />
/////<reference path="../animation/Sprite.ts"/>
/////<reference path="../system/Timer.ts"/>
/////<reference path="../Game.ts"/>
/////<reference path="BaseWeapon.ts"/>
/////<reference path="Drill.ts"/>

//class Blowtorch extends Drill
//{
//    constructor(ammo)
//    {
//        super(ammo,
//            "Blowtorch",
//            Sprites.weaponIcons.blowTorch,
//            Sprites.worms.takeOutBlowtorch,
//            Sprites.worms.blowtorching
//        )
//    }

//}