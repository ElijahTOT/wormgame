sudo apt-get install git
sudo apt-get install python-software-properties -y
sudo apt-get install software-properties-common
sudo add-apt-repository ppa:chris-lea/node.js
sudo apt-get update
sudo apt-get install nodejs npm -y
npm install validator
sudo apt-get install upstart
sudo apt-get install iftop
sudo apt-get install gcc g++ libcurl4-gnutls-dev
npm install node-curl